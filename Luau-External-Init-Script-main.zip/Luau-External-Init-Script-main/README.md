# Luau External Init Script
Optimized environment for Luau External Executors that focuses on functionality and prioritizes realism.

## Star History

<a href="https://www.star-history.com/?repos=RazAPIx64%2FLuau-External-Init-Script&type=date&legend=top-left">
 <picture>
   <source media="(prefers-color-scheme: dark)" srcset="https://api.star-history.com/image?repos=RazAPIx64/Luau-External-Init-Script&type=date&theme=dark&legend=top-left" />
   <source media="(prefers-color-scheme: light)" srcset="https://api.star-history.com/image?repos=RazAPIx64/Luau-External-Init-Script&type=date&legend=top-left" />
   <img alt="Star History Chart" src="https://api.star-history.com/image?repos=RazAPIx64/Luau-External-Init-Script&type=date&legend=top-left" />
 </picture>
</a>
